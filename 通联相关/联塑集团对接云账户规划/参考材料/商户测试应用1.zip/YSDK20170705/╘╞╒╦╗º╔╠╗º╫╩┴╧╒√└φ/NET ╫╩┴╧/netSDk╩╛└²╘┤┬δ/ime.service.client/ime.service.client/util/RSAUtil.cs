﻿using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Encodings;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Parameters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace ime.service.util
{
    public class RSAUtil
    {
        private RSACryptoServiceProvider publicKey;
        private RSACryptoServiceProvider privateKey;

        public RSAUtil(RSACryptoServiceProvider publicKey, RSACryptoServiceProvider privateKey)
        {
            this.publicKey = publicKey;
            this.privateKey = privateKey;
        }

        /// <summary>
        /// 私钥加密。
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public String encrypt(string data)
        {
            RSAParameters parameters = privateKey.ExportParameters(true);

            AsymmetricKeyParameter bouncyCastlePrivateKey = new RsaPrivateCrtKeyParameters(
                                                                  new Org.BouncyCastle.Math.BigInteger(1, parameters.Modulus),
                                                                  new Org.BouncyCastle.Math.BigInteger(1, parameters.Exponent),
                                                                  new Org.BouncyCastle.Math.BigInteger(1, parameters.D),
                                                                  new Org.BouncyCastle.Math.BigInteger(1, parameters.P),
                                                                  new Org.BouncyCastle.Math.BigInteger(1, parameters.Q),
                                                                  new Org.BouncyCastle.Math.BigInteger(1, parameters.DP),
                                                                  new Org.BouncyCastle.Math.BigInteger(1, parameters.DQ),
                                                                  new Org.BouncyCastle.Math.BigInteger(1, parameters.InverseQ));
            byte[] encryptData = Encoding.UTF8.GetBytes(data);
            var cipher = new Pkcs1Encoding(new RsaEngine());
            cipher.Init(true, bouncyCastlePrivateKey);  //true表示加密
            var blockSize = cipher.GetInputBlockSize();
            byte[] _data = cipher.ProcessBlock(encryptData, 0, encryptData.Length);

            return Convert.ToBase64String(_data);
        }

        /// <summary>
        /// 公钥解密。
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public string dencrypt(string data)
        {
            byte[] dataBase64Bytes = Convert.FromBase64String(data);

            RSAParameters parameters = publicKey.ExportParameters(false);

            AsymmetricKeyParameter pubKey = new RsaKeyParameters(false, new Org.BouncyCastle.Math.BigInteger(1, parameters.Modulus), new Org.BouncyCastle.Math.BigInteger(1, parameters.Exponent));

            var cipher = new Pkcs1Encoding(new RsaEngine());
            cipher.Init(false, pubKey);//false表示解密
            var blockSize = cipher.GetInputBlockSize();
            byte[] encryptData = cipher.ProcessBlock(dataBase64Bytes, 0, dataBase64Bytes.Length);

            return Encoding.UTF8.GetString(encryptData);
        }

        /// <summary>
        /// 获取私钥
        /// </summary>
        /// <param name="alias"></param>
        /// <param name="filePath"></param>
        /// <param name="pwd"></param>
        /// <returns></returns>
        public static RSACryptoServiceProvider loadPrivateKey(string alias, string filePath, string pwd)
        {
            X509Certificate2 x509Cert = new X509Certificate2(filePath, pwd, X509KeyStorageFlags.Exportable);
            return (RSACryptoServiceProvider)x509Cert.PrivateKey;
        }

        /// <summary>
        /// 获取公钥
        /// </summary>
        /// <param name="alias"></param>
        /// <param name="filePath"></param>
        /// <param name="pwd"></param>
        /// <returns></returns>
        public static RSACryptoServiceProvider loadPublicKey(string alias, string filePath, string pwd)
        {
            X509Certificate2 x509Cert = new X509Certificate2(filePath, pwd, X509KeyStorageFlags.Exportable);
            return (RSACryptoServiceProvider)x509Cert.PublicKey.Key;
        }

        /// <summary>
        /// 私钥签名
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string Sign(RSACryptoServiceProvider _privateKey, String text)
        {
            RSAPKCS1SignatureFormatter rsaPKCS1SignatureFormatter = new RSAPKCS1SignatureFormatter(_privateKey);
            rsaPKCS1SignatureFormatter.SetHashAlgorithm("SHA1");
            SHA1CryptoServiceProvider sha1 = new SHA1CryptoServiceProvider();

            var sha1HashResultBytes = sha1.ComputeHash(Encoding.UTF8.GetBytes(text));
            byte[] signDate = rsaPKCS1SignatureFormatter.CreateSignature(sha1HashResultBytes);
            return Convert.ToBase64String(signDate);
        }

        /// <summary>
        /// 公钥验签
        /// </summary>
        /// <param name="text"></param>
        /// <param name="signData"></param>
        /// <returns></returns>
        public static bool verify(RSACryptoServiceProvider _publicKey,String text, String signData)
        {
            _publicKey.ImportCspBlob(_publicKey.ExportCspBlob(false));
            RSAPKCS1SignatureDeformatter rsaPKCS1SignatureDeformatter = new RSAPKCS1SignatureDeformatter(_publicKey);
            rsaPKCS1SignatureDeformatter.SetHashAlgorithm("SHA1");
            SHA1CryptoServiceProvider sha1 = new SHA1CryptoServiceProvider();
            byte[] textBytes = sha1.ComputeHash(Encoding.UTF8.GetBytes(text));
            byte[] signDateBytes = Convert.FromBase64String(signData);
            return rsaPKCS1SignatureDeformatter.VerifySignature(textBytes, signDateBytes);
        }
    }
}
