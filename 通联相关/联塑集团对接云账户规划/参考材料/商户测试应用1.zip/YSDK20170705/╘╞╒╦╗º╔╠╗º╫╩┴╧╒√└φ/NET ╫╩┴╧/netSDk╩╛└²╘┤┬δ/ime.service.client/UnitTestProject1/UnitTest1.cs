﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ime.service.client;
using ime.service.util;
using System.Security.Cryptography;
using Newtonsoft.Json.Linq;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            try
            {
                string serverAddress = "http://122.227.225.142:23661/service/soa";
                string sysId = "100000000002";
                string pwd = "697057";
                string alias = "100000000002";
                string path = "E:\\pfx\\100000000002.pfx";
                string soaName = "MemberService";

                RSACryptoServiceProvider publicKey = RSAUtil.loadPublicKey(alias, path, pwd);
                RSACryptoServiceProvider privateKey = RSAUtil.loadPrivateKey(alias, path, pwd);

                SOAClient client = new SOAClient();
                client.setServerAddress(serverAddress);
                client.setPrivateKey(privateKey);
                client.setPublicKey(publicKey);
                client.setSysId(sysId);
                //client.setTimeStr("2017-03-06 21:20:09");

                JObject param = new JObject();
                param.Add("source", 1);
                param.Add("memberType", 3);
                param.Add("bizUserId", "张雄fadf45126");

                JObject ret = client.request(soaName, "createMember", param);
                System.Console.WriteLine(ret.ToString());
            }catch(Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
           
        }
    }
}
