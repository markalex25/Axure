﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace ime.service.util
{
    public class HTTPUtil
    {
        public static string post(string url, string data)
        {
            WebRequest request = null;
            Stream requestStream = null;
            WebResponse response = null;

            try
            {
                byte[] bytes = Encoding.UTF8.GetBytes(data);

                request = WebRequest.Create(url);
                request.Method = "POST";
                request.ContentLength = data.Length;
                request.ContentType = "application/x-www-form-urlencoded";
                request.Proxy = null;

                requestStream = request.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);

                //得到返回值
                response = request.GetResponse();
                string responseStr = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding("utf-8")).ReadToEnd();

                return responseStr;
            }catch(Exception e)
            {
                throw e;
            }
            finally
            {
                if(request != null)
                {
                    request.Abort();
                }
                if(requestStream != null)
                {
                    requestStream.Close();
                }
                if(response != null)
                {
                    response.Close();
                }
            }
            
        }
    }
}
