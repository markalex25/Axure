﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ime.service
{
    class Test
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("aaa");
        }
    }
}
