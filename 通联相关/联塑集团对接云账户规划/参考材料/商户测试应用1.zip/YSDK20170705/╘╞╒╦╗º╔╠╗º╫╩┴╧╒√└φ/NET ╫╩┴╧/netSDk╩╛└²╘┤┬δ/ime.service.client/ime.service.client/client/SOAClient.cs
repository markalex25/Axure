﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using ime.service.util;
using System.Web;
using Newtonsoft.Json;

namespace ime.service.client
{
    public class SOAClient
    {
        private string serverAddress = null;
        private string sysId = null;
        private string signMethod;
        private RSACryptoServiceProvider publicKey = null;
        private RSACryptoServiceProvider privateKey = null;
        private string version = "1.0";
        private string ssoid = "ime_public_ssoid";
        private string timeStr = null;
        private string timeFormatStr = "yyyy-MM-dd HH:mm:ss";

        public void setServerAddress(string serverAddress)
        {
            this.serverAddress = serverAddress;
        }
        public void setSysId(string sysId)
        {
            this.sysId = sysId;
        }
        public void setSignMethod(string signMethod)
        {
            this.signMethod = signMethod;
        }
        public void setPublicKey(RSACryptoServiceProvider publicKey)
        {
            this.publicKey = publicKey;
        }
        public void setPrivateKey(RSACryptoServiceProvider privateKey)
        {
            this.privateKey = privateKey;
        }
        public void setVersion(string version)
        {
            this.version = version;
        }
        public void setTimeStr(string timeStr)
        {
            this.timeStr = timeStr;
        }

        public JObject request(string service, string method, JObject param)
        {
            if(serverAddress == null)
            {
                throw new Exception("请设置serverAddress");
            }
            if (sysId == null)
            {
                throw new Exception("请设置sysId");
            }
            if (publicKey == null)
            {
                throw new Exception("请设置publicKey");
            }
            if (privateKey == null)
            {
                throw new Exception("请设置privateKey");
            }

            JObject req = new JObject();
            req.Add("param", param);
            req.Add("service", service);
            req.Add("method", method);
            
            string reqStr = Newtonsoft.Json.JsonConvert.SerializeObject(req);

            String timestamp = timeStr != null ? timeStr : DateTime.Now.ToString(timeFormatStr);

            //签名
            StringBuilder signSb = new StringBuilder();
            signSb.Append(sysId).Append(reqStr).Append(timestamp);
            string signStr =  RSAUtil.Sign(privateKey, signSb.ToString());

            //组装请求参数
            Dictionary<string, string> requestParams = new Dictionary<string, string>();
            requestParams.Add("sysid", sysId);
            requestParams.Add("sign", signStr);
            requestParams.Add("timestamp", timestamp);
            requestParams.Add("v", version);
            requestParams.Add("req", reqStr);
            requestParams.Add("ssoid", ssoid);

            StringBuilder requestSb = new StringBuilder();
            foreach (KeyValuePair<string, string> requestParamsOne in requestParams)
            {
                requestSb.Append(requestParamsOne.Key).Append("=").Append(HttpUtility.UrlEncode(requestParamsOne.Value, Encoding.UTF8)).Append("&");
            }

            string responseStr = HTTPUtil.post(this.serverAddress, requestSb.ToString());

            JObject responseJObj = JsonConvert.DeserializeObject<JObject>(responseStr);

            //验签
            string value = (string)responseJObj["signedValue"];
            string sign = (string)responseJObj["sign"];
            string status = (string)responseJObj["status"];
            if (!RSAUtil.verify(publicKey, value, sign))
            {
                throw new Exception("返回值验签失败");
            }

            return responseJObj;
        }

       
    }
}
